<?php
$db_type="mysql"; 
$stats_password="PASSWORD"; //Senha para acessar os stats.php. Altere!!!
$enable_id_obfuscation=true; 
$redact_ip_addresses=false;

// Sqlite3 settings
$Sqlite_db_file = "../../speedtest_telemetry.sql";

// Mysql settings
$MySql_username="librespeed";
$MySql_password="senha"; // Altere!!!
$MySql_hostname="localhost";
$MySql_databasename="librespeed";

// Postgresql settings
$PostgreSql_username="USERNAME";
$PostgreSql_password="PASSWORD";
$PostgreSql_hostname="DB_HOSTNAME";
$PostgreSql_databasename="DB_NAME";
?>