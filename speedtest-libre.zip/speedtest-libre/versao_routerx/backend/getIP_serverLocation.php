<?php
$serverLoc="-27.3592,-53.3944";
?>